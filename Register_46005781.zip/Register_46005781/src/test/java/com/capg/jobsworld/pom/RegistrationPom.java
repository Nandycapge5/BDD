package com.capg.jobsworld.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import jobsworld.WebUtil;

public class RegistrationPom {
//create the object for web driver
	static WebDriver driver;

	public static WebDriver getWebDriver() {
		driver = WebUtil.getWebDriver();
		return driver;
	}

	public static WebElement getUserField() {
		return driver.findElement(By.id("usrID"));

	}

	public static WebElement getPasswordField() {
		return driver.findElement(By.id("pwd"));

	}

	public static WebElement getNameField() {
		return driver.findElement(By.id("usrname"));

	}

	public static WebElement getAddressField() {
		return driver.findElement(By.id("addr"));

	}

	public static WebElement getCountryField() {
		return driver.findElement(By.name("country"));

	}

	public static WebElement getZipCodeField() {
		return driver.findElement(By.name("zip"));

	}

	public static WebElement getEmailField() {
		return driver.findElement(By.name("email"));

	}

	public static WebElement getGenderField() {
		return driver.findElement(By.xpath("/html/body/form/ul/li[16]/input"));

	}

	public static WebElement submitButton() {
		return driver.findElement(By.name("submit"));
	}

}
