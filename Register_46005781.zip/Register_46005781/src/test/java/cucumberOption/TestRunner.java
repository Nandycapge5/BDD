package cucumberOption;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;



@RunWith(Cucumber.class)
@CucumberOptions(
      //feature file
		features = "C:\\Users\\nashanmu\\Desktop\\BDD Test\\Register\\src\\test\\resource\\feature\\Register.feature",
      //step definition file
		glue= {"stepdefinition"},
       monochrome=false,
       plugin = {"html:target/Destination"}
       )
public class TestRunner {

}
