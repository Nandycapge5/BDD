package Booking_Test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		
features= {"C:\\Users\\nashanmu\\Desktop\\BDD Test\\HotelBooking\\src\\test\\resource\\Booking\\Booking.feature"},
glue= {"Booking_Test"},
dryRun = false,
strict = true,
monochrome= true,
format = {"pretty" , "html:test-output"}



)

public class BookingTestRunner {

	
	
}
