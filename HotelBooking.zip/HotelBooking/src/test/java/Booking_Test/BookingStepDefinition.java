package Booking_Test;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pagebean.BookingPageFactory;

public class BookingStepDefinition {
	private WebDriver driver;
	private BookingPageFactory bookingPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nashanmu\\Desktop\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'hotelbooking' page$")
	public void user_is_on_hotelbooking_page() throws Throwable {
		driver.get("C:\\Users\\nashanmu\\Downloads\\BDDCaseStudyFinal\\hotelbooking.html");
		bookingPageFactory= new BookingPageFactory(driver); 
	}

	@When("^users entered invalid firstname$")
	public void users_entered_invalid_firstname() throws Throwable {
		bookingPageFactory.setFirstName("");
		bookingPageFactory.setConfirmBooking();
	}

	@Then("^displays 'please enter  first name'$")
	public void displays_please_enter_first_name() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^users entered invalid lastname$")
	public void users_entered_invalid_lastname() throws Throwable {
		bookingPageFactory.setFirstName("nan");
		bookingPageFactory.setLastName("");
		bookingPageFactory.setConfirmBooking();  
	}

	@Then("^displays 'please enter  last name'$")
	public void displays_please_enter_last_name() throws Throwable {
		String expectedmessage1="Please fill the last name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedmessage1, actualMessage);
		driver.switchTo().alert().accept();
	   
	}

	@When("^users entered invalid Email$")
	public void users_entered_invalid_Email() throws Throwable {
		bookingPageFactory.setFirstName("nandhu");
		bookingPageFactory.setLastName("san");
		bookingPageFactory.setEmail("");
		
	 bookingPageFactory.setConfirmBooking();
	}

	@Then("^displays 'please enter the email'$")
	public void displays_please_enter_the_email() throws Throwable {
		 String expectedMessage="Please fill the email";
		 String actualMessage=driver.switchTo().alert().getText();
		 Assert.assertEquals(expectedMessage,actualMessage);
		 driver.switchTo().alert().accept();
		 driver.close();
	}

	@Given("^user is on 'hotelBooking' page$")
	public void user_is_on_hotelBooking_page() throws Throwable {
		driver.get("C:\\Users\\nashanmu\\Downloads\\BDDCaseStudyFinal\\hotelbooking.html");
		bookingPageFactory= new BookingPageFactory(driver); 
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		bookingPageFactory.setFirstName("nandhu");
		bookingPageFactory.setLastName("san");
		bookingPageFactory.setEmail("abc@gmail.com");
		bookingPageFactory.setMobileNo(" ");
		bookingPageFactory.setConfirmBooking();
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No()  {
	    String expec="Please fill the Mobile No.";
	    String actual=driver.switchTo().alert().getText();
	    Assert.assertEquals(expec, actual);
	    driver.switchTo().alert().accept();
	    driver.close();
	}

	@Then("^display 'Please enter valid Mobile Number'$")
	public void display_Please_enter_valid_Mobile_Number() throws Throwable {
		String expected="Please enter valid Contact no.";
		 String actualMes=driver.switchTo().alert().getText();
		 Assert.assertEquals(expected,actualMes);
		 driver.switchTo().alert().accept();
		 driver.close();

	}

	@When("^user does not enter address$")
	public void user_does_not_enter_address() throws Throwable {
		bookingPageFactory.setFirstName("nandhu");
		bookingPageFactory.setLastName("san");
		bookingPageFactory.setEmail("abc@gmail.com");
		bookingPageFactory.setMobileNo("9863258741");
		bookingPageFactory.setAddress("");   
	}

	@Then("^display 'Please Enter Address'$")
	public void display_Please_Enter_Address() throws Throwable {
		String expected="Chennai";
		 String actualMes=driver.switchTo().alert().getText();
		 Assert.assertEquals(expected,actualMes);
		 driver.switchTo().alert().accept();
		 driver.close();
	}

	@When("^user enters invalid city$")
	public void user_enters_invalid_city() throws Throwable {
		bookingPageFactory.setFirstName("nandhu");
		bookingPageFactory.setLastName("san");
		bookingPageFactory.setEmail("abc@gmail.com");
		bookingPageFactory.setMobileNo("9863258741");
		bookingPageFactory.setAddress("dfrtgr");
		bookingPageFactory.setCity("Select City");
		bookingPageFactory.setConfirmBooking();
	}

	@Then("^display 'Please enter the city'$")
	public void display_Please_enter_the_city() throws Throwable {
	   String excpt="Please select city";
	   String actu=driver.switchTo().alert().getText();
	   Assert.assertEquals(excpt, actu);
	   driver.switchTo().alert().accept();
	   driver.close();
	}

	@When("^user enters invalid state$")
	public void user_enters_invalid_state() throws Throwable {
		bookingPageFactory.setFirstName("nandhu");
		bookingPageFactory.setLastName("san");
		bookingPageFactory.setEmail("abc@gmail.com");
		bookingPageFactory.setMobileNo("9863258741");
		bookingPageFactory.setAddress("dfrtgr");
		bookingPageFactory.setCity("coimbatore");
		bookingPageFactory.setState(" ");
		bookingPageFactory.setConfirmBooking();
	}

	@Then("^display 'Please enter the state'$")
	public void display_Please_enter_the_state() throws Throwable {
		 String excpt="Please select state";
		 String actual=driver.switchTo().alert().getText();
		 Assert.assertEquals(excpt, actual);
		   driver.switchTo().alert().accept();
		 driver.close();
	}



}
