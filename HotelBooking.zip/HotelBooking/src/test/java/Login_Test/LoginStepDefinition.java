package Login_Test;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagebean.LoginPageFactory;

public class LoginStepDefinition {

	
public WebDriver driver;
public LoginPageFactory loginpage;
	
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() {
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nashanmu\\Desktop\\Driver\\chromedriver.exe" );
		driver= new ChromeDriver();
		driver.get("C:\\Users\\nashanmu\\Desktop\\BDD Test\\HotelBooking\\login.html");
		loginpage = new LoginPageFactory(driver);
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() {
		String bodyTest=driver.findElement(By.xpath("//h1[@align='center']")).getText() ;
		   System.out.println(bodyTest);
		   Assert.assertEquals("Hotel Booking Application",bodyTest);
	}
	@When("^user enter invalid username$")
	public void user_enter_invalid_username()  {
		loginpage.setUname("");
		loginpage.setLogin();
	    
	}

	@Then("^displays \\* Please enter userName\\.$")
	public void displays_Please_enter_userName()  {
	   
	   String exp="* Please enter userName.";
	   String actual=loginpage.getError().getText();
	   Assert.assertEquals(exp, actual);
	   driver.close();
	}

	@When("^user enter invalid password$")
	public void user_enter_invalid_password()  {
	   loginpage.setPass("");
	   loginpage.setLogin();
	}

	@Then("^displays \\* Please enter password\\.\\.$")
	public void displays_Please_enter_password()  {
	 String ex="* Please enter password.";
	 String ac=loginpage.getPasserror().getText();
	 Assert.assertEquals(ex, ac);
	 driver.close();
	}

	@When("^user enter the valid username and password$")
	public void user_enter_the_valid_username_and_password()  {
		loginpage.setUname("Capgemini");
		loginpage.setPass("capg1234");
	}

	@Then("^displays \"([^\"]*)\"$")
	public void displays(String arg1)  {
	   driver.get("C:\\Users\\nashanmu\\Desktop\\BDD Test\\HotelBooking\\hotelbooking.html");
	}


}
