package pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {

	WebDriver driver;
	@FindBy(name="userName")
	@CacheLookup
	WebElement uname;
	
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pass;
	
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement login;

	@FindBy(className="errMessage")
	@CacheLookup
	WebElement error;
	
	@FindBy(id="pwdErrMsg")
	@CacheLookup
	WebElement passerror;
	
	

	public WebElement getError() {
		return error;
	}


	public WebElement getPasserror() {
		return passerror;
	}


	public void setPasserror(WebElement passerror) {
		this.passerror = passerror;
	}


	public void setError(WebElement error) {
		this.error = error;
	}


	public LoginPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}


	public WebElement getUname() {
		return uname;
	}


	public void setUname(String uname) {
		this.uname.sendKeys(uname);
	}


	public WebElement getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass.sendKeys(pass);;
	}


	public WebElement getLogin() {
		return login;
	}


	public void setLogin() {
		this.login.click();
	}
	
	
}
