package elementLocators;

import org.openqa.selenium.By;

public class ElementLocator {
	
	public static By Title=By.xpath("//h1[text()=' Registeration Form ']");
	
	public static By userId=By.id("usrID");
	public static By password=By.id("pwd");	
	public static By Name=By.id("usrname");
	public static By address=By.id("addr");
	public static By country=By.xpath("//select[@name='country']");	
	public static By zip=By.name("zip");
	public static By email=By.name("email");
	public static By sex=By.xpath("//input[@value='Female']");
	public static By language=By.xpath("//input[@name='en']");
	
	public static By submit=By.xpath("//input[@value='Submit']");

}
