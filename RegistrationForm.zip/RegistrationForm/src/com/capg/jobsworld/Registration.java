package com.capg.jobsworld;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "feature/Registration.feature", plugin = "pretty")
public class Registration {
	public static void main(String[] args) {

	}

}
