$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nashanmu/Desktop/BDD Test/AmazonEx/src/test/resource/com/cap/feature/Amazon.feature");
formatter.feature({
  "line": 2,
  "name": "Validating the amazon application",
  "description": "",
  "id": "validating-the-amazon-application",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Search an item and get the title",
  "description": "",
  "id": "validating-the-amazon-application;search-an-item-and-get-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "the user is on the amazon home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "select the category as Books",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should enter the da vinci code int he search textbox",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "the user should click on manifier button",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "get the title of the books and print",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginStepDefintion.the_user_is_on_the_amazon_home_page()"
});
formatter.result({
  "duration": 138169400,
  "error_message": "java.lang.NoClassDefFoundError: com/google/common/collect/ImmutableMap\r\n\tat org.openqa.selenium.remote.service.DriverService$Builder.\u003cinit\u003e(DriverService.java:250)\r\n\tat org.openqa.selenium.chrome.ChromeDriverService$Builder.\u003cinit\u003e(ChromeDriverService.java:98)\r\n\tat org.openqa.selenium.chrome.ChromeDriverService.createDefaultService(ChromeDriverService.java:91)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat com.cap.login.LoginStepDefintion.the_user_is_on_the_amazon_home_page(LoginStepDefintion.java:22)\r\n\tat ✽.Given the user is on the amazon home page(C:/Users/nashanmu/Desktop/BDD Test/AmazonEx/src/test/resource/com/cap/feature/Amazon.feature:6)\r\nCaused by: java.lang.ClassNotFoundException: com.google.common.collect.ImmutableMap\r\n\tat java.net.URLClassLoader.findClass(Unknown Source)\r\n\tat java.lang.ClassLoader.loadClass(Unknown Source)\r\n\tat sun.misc.Launcher$AppClassLoader.loadClass(Unknown Source)\r\n\tat java.lang.ClassLoader.loadClass(Unknown Source)\r\n\tat org.openqa.selenium.remote.service.DriverService$Builder.\u003cinit\u003e(DriverService.java:250)\r\n\tat org.openqa.selenium.chrome.ChromeDriverService$Builder.\u003cinit\u003e(ChromeDriverService.java:98)\r\n\tat org.openqa.selenium.chrome.ChromeDriverService.createDefaultService(ChromeDriverService.java:91)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat com.cap.login.LoginStepDefintion.the_user_is_on_the_amazon_home_page(LoginStepDefintion.java:22)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:40)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:34)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:38)\r\n\tat cucumber.runtime.StepDefinitionMatch.runStep(StepDefinitionMatch.java:37)\r\n\tat cucumber.runtime.Runtime.runStep(Runtime.java:300)\r\n\tat cucumber.runtime.model.StepContainer.runStep(StepContainer.java:44)\r\n\tat cucumber.runtime.model.StepContainer.runSteps(StepContainer.java:39)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:44)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:102)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:95)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:38)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:100)\r\n\tat org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:86)\r\n\tat org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:38)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:538)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:760)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:460)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:206)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "LoginStepDefintion.select_the_category_as_Books()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefintion.the_user_should_enter_the_da_vinci_code_int_he_search_textbox()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefintion.the_user_should_click_on_manifier_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "LoginStepDefintion.get_the_title_of_the_books_and_print()"
});
formatter.result({
  "status": "skipped"
});
});