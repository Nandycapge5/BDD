package com.cap.login;

import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginStepDefintion {
	WebDriver Driver; 
	@Given("^the user is on the amazon home page$")
	public void the_user_is_on_the_amazon_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nashanmu\\Desktop\\chromedriver_win32\\chromedriver.exe");
        Driver = new ChromeDriver();
        Driver.get("https://www.amazon.in/"); 
	   
	}

	@Then("^select the category as Books$")
	public void select_the_category_as_Books() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement Ele = Driver.findElement(By.xpath("//select[@id='searchDropdownBox']"));
        Select Select_Category = new Select(Ele);
        Select_Category.selectByIndex(11);
		
	  
	}

	@Then("^the user should enter the da vinci code int he search textbox$")
	public void the_user_should_enter_the_da_vinci_code_int_he_search_textbox() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 String Search_term = "Da Vinci Code";
	        Driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Search_term);
	
	}

	@Then("^the user should click on manifier button$")
	public void the_user_should_click_on_manifier_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Driver.findElement(By.xpath("//input[@tabindex = '10']")).click();
	   
	}

	@Then("^get the title of the books and print$")
	public void get_the_title_of_the_books_and_print() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 List<WebElement> Titles = Driver.findElements(By.xpath("//span[@class = 'a-size-medium a-color-base a-text-normal']"));
	        
	        for(WebElement ttl : Titles) {
	            System.out.println(ttl.getText());
		
	    
	}
Driver.close();
	}
}
