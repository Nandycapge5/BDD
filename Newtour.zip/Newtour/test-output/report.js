$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nashanmu/Desktop/BDD Test/Newtour/src/test/resource/Tour/NewTourBooking.feature");
formatter.feature({
  "line": 1,
  "name": "validate the newtour aplication to book al flight",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 10,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 12,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 15
    },
    {
      "cells": [
        "2"
      ],
      "line": 16
    },
    {
      "cells": [
        "3"
      ],
      "line": 17
    },
    {
      "cells": [
        "4"
      ],
      "line": 18
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "user enter \"\u003cDeparture\u003e\" and \"\u003cArrival\u003e\" location",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "click on continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.examples({
  "line": 24,
  "name": "",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;",
  "rows": [
    {
      "cells": [
        "Departure",
        "Arrival"
      ],
      "line": 25,
      "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;1"
    },
    {
      "cells": [
        "London",
        "Paris"
      ],
      "line": 26,
      "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;2"
    },
    {
      "cells": [
        "Paris",
        "London"
      ],
      "line": 27,
      "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;3"
    },
    {
      "cells": [
        "New York",
        "Paris"
      ],
      "line": 28,
      "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;4"
    },
    {
      "cells": [
        "London",
        "Zurich"
      ],
      "line": 29,
      "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 4,
  "name": "The user should logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 26,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 12,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 15
    },
    {
      "cells": [
        "2"
      ],
      "line": 16
    },
    {
      "cells": [
        "3"
      ],
      "line": 17
    },
    {
      "cells": [
        "4"
      ],
      "line": 18
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "user enter \"London\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "click on continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 4,
  "name": "The user should logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 27,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 12,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 15
    },
    {
      "cells": [
        "2"
      ],
      "line": 16
    },
    {
      "cells": [
        "3"
      ],
      "line": 17
    },
    {
      "cells": [
        "4"
      ],
      "line": 18
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "user enter \"Paris\" and \"London\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "click on continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 4,
  "name": "The user should logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 28,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 12,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 15
    },
    {
      "cells": [
        "2"
      ],
      "line": 16
    },
    {
      "cells": [
        "3"
      ],
      "line": 17
    },
    {
      "cells": [
        "4"
      ],
      "line": 18
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "user enter \"New York\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "click on continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 4,
  "name": "The user should logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 29,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-aplication-to-book-al-flight;enter-the-details-in-for-booking-a-flight;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 12,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 15
    },
    {
      "cells": [
        "2"
      ],
      "line": 16
    },
    {
      "cells": [
        "3"
      ],
      "line": 17
    },
    {
      "cells": [
        "4"
      ],
      "line": 18
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "user enter \"London\" and \"Zurich\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "click on continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});