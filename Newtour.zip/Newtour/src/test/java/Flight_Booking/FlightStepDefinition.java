package Flight_Booking;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class FlightStepDefinition {

	
	
	
	@Given("^the user is on login page$")
	public void the_user_is_on_login_page()  {
	
	
	}

	@Then("^the user enter to \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enter_to_and(String arg1, String arg2)  {
	    
	}

	@Then("^the user should Click on Signin button$")
	public void the_user_should_Click_on_Signin_button() {
		
		
	}

	@Given("^the user is on flight reservation page$")
	public void the_user_is_on_flight_reservation_page() {
	    
	}

	@Then("^select the passenger count$")
	public void select_the_passenger_count(DataTable arg1) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	  
	}

	@Then("^user enter \"([^\"]*)\" and \"([^\"]*)\" location$")
	public void user_enter_and_location(String arg1, String arg2) {
	   
	    
	}

	@Then("^click on continue booking the flight ticket\\.$")
	public void click_on_continue_booking_the_flight_ticket()  {
	  
	}


}
