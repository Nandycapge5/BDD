package Flight_Booking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
features= {"C:\\Users\\nashanmu\\Desktop\\BDD Test\\Newtour\\src\\test\\resource\\Tour\\NewTourBooking.feature"},
glue= {"Flight_Booking"},
dryRun = true,
strict = false,
monochrome= true,
format = {"pretty" , "html:test-output"}



)
public class FlightTestRunner {

}
